CREATE TABLE class (
  id INTEGER PRIMARY KEY,
  name varchar(100) NOT NULL default '',
  type varchar(255) default '',
  alignment varchar(255) default '',
  hit_die varchar(255) default '',
  class_skills longtext,
  skill_points varchar(255) default '',
  skill_points_ability varchar(255) default '',
  spell_stat varchar(255) default '',
  proficiencies longtext,
  spell_type varchar(255) default '',
  epic_feat_base_level varchar(255) default '',
  epic_feat_interval varchar(255) default '',
  epic_feat_list longtext,
  epic_full_text longtext,
  req_race varchar(255) default '',
  req_weapon_proficiency varchar(255) default '',
  req_base_attack_bonus varchar(255) default '',
  req_skill varchar(255) default '',
  req_feat varchar(255) default '',
  req_spells varchar(255) default '',
  req_languages varchar(255) default '',
  req_psionics varchar(255) default '',
  req_epic_feat varchar(255) default '',
  req_special varchar(255) default '',
  spell_list_1 longtext,
  spell_list_2 varchar(255) default '',
  spell_list_3 varchar(255) default '',
  spell_list_4 varchar(255) default '',
  spell_list_5 varchar(255) default '',
  full_text longtext,
  reference varchar(255) default ''
);
CREATE INDEX class_name_idx ON class(name);

CREATE TABLE class_table (
  id INTEGER PRIMARY KEY,
  name varchar(100) NOT NULL default '',
  level varchar(255) default '',
  base_attack_bonus varchar(255) default '',
  fort_save varchar(255) default '',
  ref_save varchar(255) default '',
  will_save varchar(255) default '',
  caster_level varchar(255) default '',
  points_per_day varchar(255) default '',
  ac_bonus varchar(255) default '',
  flurry_of_blows varchar(255) default '',
  bonus_spells varchar(255) default '',
  powers_known varchar(255) default '',
  unarmored_speed_bonus varchar(255) default '',
  unarmed_damage varchar(255) default '',
  power_level varchar(255) default '',
  special varchar(255) default '',
  slots_0 varchar(255) default '',
  slots_1 varchar(255) default '',
  slots_2 varchar(255) default '',
  slots_3 varchar(255) default '',
  slots_4 varchar(255) default '',
  slots_5 varchar(255) default '',
  slots_6 varchar(255) default '',
  slots_7 varchar(255) default '',
  slots_8 varchar(255) default '',
  slots_9 varchar(255) default '',
  spells_known_0 varchar(255) default '',
  spells_known_1 varchar(255) default '',
  spells_known_2 varchar(255) default '',
  spells_known_3 varchar(255) default '',
  spells_known_4 varchar(255) default '',
  spells_known_5 varchar(255) default '',
  spells_known_6 varchar(255) default '',
  spells_known_7 varchar(255) default '',
  spells_known_8 varchar(255) default '',
  spells_known_9 varchar(255) default '',
  reference varchar(255) default ''
);
CREATE INDEX class_table_name_idx ON class_table(name);


CREATE TABLE domain (
  id INTEGER PRIMARY KEY,
  name varchar(100) NOT NULL default '',
  granted_powers longtext,
  spell_1 varchar(255) default '',
  spell_2 varchar(255) default '',
  spell_3 varchar(255) default '',
  spell_4 varchar(255) default '',
  spell_5 varchar(255) default '',
  spell_6 varchar(255) default '',
  spell_7 varchar(255) default '',
  spell_8 varchar(255) default '',
  spell_9 varchar(255) default '',
  full_text longtext,
  reference varchar(255) default ''
);
CREATE INDEX domain_name_idx ON domain(name);

CREATE TABLE equipment (
  id INTEGER PRIMARY KEY,
  name varchar(100) NOT NULL default '',
  family varchar(255) default '',
  category varchar(255) default '',
  subcategory varchar(255) default '',
  cost varchar(255) default '',
  dmg_s varchar(255) default '',
  armor_shield_bonus varchar(255) default '',
  maximum_dex_bonus varchar(255) default '',
  dmg_m varchar(255) default '',
  weight varchar(255) default '',
  critical varchar(255) default '',
  armor_check_penalty varchar(255) default '',
  arcane_spell_failure_chance varchar(255) default '',
  range_increment varchar(255) default '',
  speed_30 varchar(255) default '',
  type varchar(255) default '',
  speed_20 varchar(255) default '',
  full_text longtext,
  reference varchar(255) default ''
);
CREATE INDEX equipment_name_idx ON equipment(name);

CREATE TABLE feat (
  id INTEGER PRIMARY KEY,
  name varchar(100) NOT NULL default '',
  type varchar(255) default '',
  multiple varchar(255) default '',
  stack varchar(255) default '',
  choice varchar(255) default '',
  prerequisite longtext,
  benefit longtext,
  normal longtext,
  special longtext,
  full_text longtext,
  reference varchar(255) default ''
);
CREATE INDEX feat_name_idx ON feat(name);

--
-- Table structure for table `item`
--

CREATE TABLE item (
  id INTEGER PRIMARY KEY,
  name varchar(100) NOT NULL default '',
  category varchar(255) default '',
  subcategory varchar(255) default '',
  special_ability varchar(255) default '',
  aura varchar(255) default '',
  caster_level varchar(255) default '',
  price varchar(255) default '',
  manifester_level varchar(255) default '',
  prereq longtext,
  cost varchar(255) default '',
  weight varchar(255) default '',
  full_text longtext,
  reference varchar(255) default ''
);
CREATE INDEX item_name_idx ON item(name);

--
-- Table structure for table `monster`
--

CREATE TABLE monster (
  id INTEGER PRIMARY KEY,
  family varchar(255) default '',
  name varchar(100) NOT NULL default '',
  altname varchar(255) default '',
  size varchar(255) default '',
  type varchar(255) default '',
  descriptor varchar(255) default '',
  hit_dice varchar(255) default '',
  initiative varchar(255) default '',
  speed varchar(255) default '',
  armor_class varchar(255) default '',
  base_attack varchar(255) default '',
  grapple varchar(255) default '',
  attack varchar(255) default '',
  full_attack longtext,
  space varchar(255) default '',
  reach varchar(255) default '',
  special_attacks varchar(255) default '',
  special_qualities longtext,
  saves varchar(255) default '',
  abilities varchar(255) default '',
  skills longtext,
  bonus_feats varchar(255) default '',
  feats longtext,
  epic_feats longtext,
  environment varchar(255) default '',
  organization longtext,
  challenge_rating varchar(255) default '',
  treasure varchar(255) default '',
  alignment varchar(255) default '',
  advancement varchar(255) default '',
  level_adjustment varchar(255) default '',
  special_abilities longtext,
  stat_block longtext,
  full_text longtext,
  reference varchar(255) default ''
);
CREATE INDEX monster_name_idx ON monster(name);

--
-- Table structure for table `power`
--

CREATE TABLE power (
  id INTEGER PRIMARY KEY,
  name varchar(100) NOT NULL default '',
  discipline varchar(255) default '',
  subdiscipline varchar(255) default '',
  descriptor varchar(255) default '',
  level varchar(255) default '',
  display varchar(255) default '',
  manifesting_time varchar(255) default '',
  range varchar(255) default '',
  target varchar(255) default '',
  area varchar(255) default '',
  effect varchar(255) default '',
  duration varchar(255) default '',
  saving_throw varchar(255) default '',
  power_points varchar(255) default '',
  power_resistance varchar(255) default '',
  short_description longtext,
  xp_cost longtext,
  description longtext,
  augment longtext,
  full_text longtext,
  reference varchar(255) default ''
);
CREATE INDEX power_name_idx ON power(name);

--
-- Table structure for table `skill`
--

CREATE TABLE skill (
  id INTEGER PRIMARY KEY,
  name varchar(100) NOT NULL default '',
  subtype longtext,
  key_ability varchar(255) default '',
  psionic varchar(255) default '',
  trained varchar(255) default '',
  armor_check varchar(255) default '',
  description longtext,
  skill_check longtext,
  action longtext,
  try_again longtext,
  special longtext,
  restriction longtext,
  synergy longtext,
  epic_use longtext,
  untrained longtext,
  full_text longtext,
  reference varchar(255) default ''
);
CREATE INDEX skill_name_idx ON skill(name);

--
-- Table structure for table `spell`
--

CREATE TABLE spell (
  id INTEGER PRIMARY KEY,
  name varchar(100) NOT NULL default '',
  altname varchar(255) default '',
  school varchar(255) default '',
  subschool varchar(255) default '',
  descriptor varchar(255) default '',
  spellcraft_dc varchar(255) default '',
  level varchar(255) default '',
  components longtext,
  casting_time varchar(255) default '',
  range varchar(255) default '',
  target varchar(255) default '',
  area varchar(255) default '',
  effect varchar(255) default '',
  duration varchar(255) default '',
  saving_throw varchar(255) default '',
  spell_resistance varchar(255) default '',
  short_description varchar(255) default '',
  to_develop longtext,
  material_components longtext,
  arcane_material_components varchar(255) default '',
  focus longtext,
  description longtext,
  xp_cost longtext,
  arcane_focus varchar(255) default '',
  wizard_focus varchar(255) default '',
  verbal_components varchar(255) default '',
  sorcerer_focus varchar(255) default '',
  bard_focus varchar(255) default '',
  cleric_focus varchar(255) default '',
  druid_focus varchar(255) default '',
  full_text longtext,
  reference varchar(255) default ''
);
CREATE INDEX spell_name_idx ON spell(name);

